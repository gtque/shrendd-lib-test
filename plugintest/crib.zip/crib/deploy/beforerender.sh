#!/bin/bash

echo "crib greeting: $(shrenddOrDefault "crib.greeting")"