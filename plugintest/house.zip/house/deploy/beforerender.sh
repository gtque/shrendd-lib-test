#!/bin/bash

echo "house greeting: $(shrenddOrDefault "house.greeting")"