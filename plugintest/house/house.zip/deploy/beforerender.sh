#!/bin/bash

echo $(shrenddOrDefault "shanty.greeting")