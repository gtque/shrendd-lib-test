#!/bin/bash

echo "mobile greeting: $(shrenddOrDefault "mobile.greeting")"