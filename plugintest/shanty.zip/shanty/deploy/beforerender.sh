#!/bin/bash

echo "shanty greeting: $(shrenddOrDefault "shanty.greeting")"