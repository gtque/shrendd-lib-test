#!/bin/bash

echo $(shrenddOrDefault "house.greeting")