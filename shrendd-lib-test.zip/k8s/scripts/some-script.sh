#!/usr/bin/env sh

echo "\"$(getConfig "lib.script.message")\""